- editing menggunakan sublime Text 3.
- sql dari xampp yaitu phpmyadmin

Tutorial :
import sensus_penduduk.sql ke dalam phpmyadmin dengan terlebih
dulu membuat database bernama sensus_penduduk