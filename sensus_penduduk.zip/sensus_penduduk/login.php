<?php 
session_start();
include 'konfig.php';
$email=$_POST['email'];
$pass=$_POST['pass'];
/*$pas=md5($pass); */

$sql="SELECT * from users where email = '$email' and password = '$pass'";
$result=mysqli_query($conn,$sql);
if(mysqli_num_rows($result)>0){
	//output data setiap baris
	while($row=mysqli_fetch_array($result)){
		$_SESSION['email']=$email;
		header("location:admin/index.php");
	}
}



// $query = "select * from users where email = '$email' and password = '$pass'";
// $result = mysqli_query($query);
// if (mysqli_num_rows($result)) {
// 	while ($row = mysqli_fetch_array($result)) {
// 		$_SESSION['email']=$email;
// 		header("location:admin/index.php");
// 	}
// }

/*$query=mysqli_query("select * from users where email='$email' and password='$pass'");
if(mysqli_num_rows($query)){
	$_SESSION['email']=$email;
	header("location:admin/index.php");
}else{
	header("location:index.php?pesan=gagal");
} */
 ?>