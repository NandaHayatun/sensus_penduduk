<?php
$conn=mysqli_connect("localhost","root","","sensus_penduduk");
if(!$conn){
	die("Connection failed : ".mysqli_connect_error());
} 
	// $server = "127.0.0.1";
	// $user = "root";
	// $pass = "";
	// $dbname = "sensus_penduduk";
        
	
	// if (mysqli_connect($server,$user,$pass)){
	// 	//echo ":)";
	// 	mysqli_select_db($dbname) or die("database not found");
	// }else{
	// 	echo ":(";
	// }

?>