<?php 
include '../konfig.php';
$nama=$_POST['name'];
$region=$_POST['region'];
$alamat=$_POST['alamat'];
$income=$_POST['income'];
$date = date('Y-m-d H:i:s');
$sql="INSERT INTO person (name_person,region_id,address,income,created_at) VALUES('$nama','$region','$alamat','$income','$date')";
if(mysqli_query($conn,$sql)){
header("Location: person.php");
}
 ?>