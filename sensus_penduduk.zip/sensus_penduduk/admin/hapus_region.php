<?php
	$iddel=$_GET['region_id'];
	include "../konfig.php";
	$sql="DELETE FROM regions WHERE region_id='$iddel'";
	if(mysqli_query($conn,$sql)){
		header("Location: region.php");
	}else{
		echo "Error!";
	}mysqli_close($conn);
	?>