<?php 
include 'header.php';
?>
<h3><span class="glyphicon glyphicon-briefcase"></span>  Edit Region</h3>
<a class="btn" href="region.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
	$idedit=$_GET['region_id'];
	include "../konfig.php";
	$sql="SELECT * FROM regions WHERE region_id='$idedit'";
	$result=mysqli_query($conn,$sql);
	while($data1 = mysqli_fetch_array($result)){
		$idambil=$data1['region_id'];
		$namanya=$data1['name'];
	}
	$namaerr="";
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		if(empty($_POST["nama"])){
      		$namaerr="Nama tidak boleh kosong!";
      	}else{
      		$id=$_POST["region_id"];
      		$nama=test_input($_POST["nama"]);
      		if(!preg_match("/^[a-zA-Z]*$/",$nama)){
        		$namaerr="Only letters and white space allowed";
        	}else{
        		include "../konfig.php";
        		$date = date('Y-m-d h:i:s');
		        $sql2="UPDATE regions set name='$nama',created_at='$date' WHERE region_id='$id'";
		        if(mysqli_query($conn,$sql2)){
		        	header("Location: region.php");
		        }else{
		          echo "Error!";
		        }mysqli_close($conn);
        	}
      	}
      	
	}
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>			
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
		<table class="table">
			<tr>
				<td>ID Region</td>
				<td><input type="text" name="region_id" value="<?php echo $idedit; ?>" readonly></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" class="form-control" name="nama" value="<?php echo $namanya ?>"></td>
			</tr>
			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Ubah"></td>
			</tr>
		</table>
	</form>
<?php include 'footer.php'; ?>