<?php include 'header.php'; ?>

<h3><span class="glyphicon glyphicon-briefcase"></span>  Data Person</h3>
<button style="margin-bottom:20px" data-toggle="modal" data-target="#myModal" class="btn btn-info col-md-2"><span class="glyphicon glyphicon-plus"></span>Tambah Person</button>
<br/>
<br/>

<?php 
include '../konfig.php';
$per_hal=10;
$jumlah_record=mysqli_query($conn, "SELECT COUNT(*) as number from person");
$jum=mysqli_fetch_array($jumlah_record);
$halaman= ceil($jum['number'] / $per_hal);
$page = (isset($_GET['page'])) ? (int)$_GET['page'] : 1;
$start = ($page - 1) * $per_hal;
?>
<div class="col-md-12">
	<table class="col-md-2">
		<tr>
			<td>Jumlah Halaman</td>	
			<td><?php echo $halaman; ?></td>
		</tr>
	</table>
</div>
<br/>
<form method="post">
Filter : <select name="tampilreg">
	<option value="all" selected="selected">All Region</option>
	<?php
	include "../konfig.php";
	$queryfil = "SELECT * FROM regions";
	$hasilfil = mysqli_query($conn,$queryfil);
	while ($datafil = mysqli_fetch_array($hasilfil))
	{
	echo "<option value='".$datafil['region_id']."'>".$datafil['name']."</option>";
	}
	?>
</select>
<input type="submit" class="btn btn-primary" value="Filter" name="filter">
</form>
<table class="table table-hover">
	<tr>
		<th class="col-md-1">ID</th>
		<th class="col-md-3">Nama</th>
		<th class="col-md-2">Region</th>
		<th class="col-md-3">Alamat</th>
		<th class="col-md-2">Income</th>
		<th class="col-md-3">Dibuat saat</th>
		<!-- <th class="col-md-1">Sisa</th>		 -->
		<th class="col-md-3">Opsi</th>
	</tr>
<?php

if (isset($_POST['filter'])) {
$fil=$_POST['tampilreg'];
if($fil == 'all'){
	include "../konfig.php";
	$sql3="SELECT  * from person,regions where person.region_id=regions.region_id limit $start, $per_hal";
	$per=mysqli_query($conn,$sql3);
	if(mysqli_num_rows($per)>0){
		//output data setiap baris
		while($r=mysqli_fetch_array($per)){
		?>
		<tr>
			<td><?php echo $r['id_person'] ?></td>
			<td><?php echo $r['name_person'] ?></td>
			<td><?php echo $r['name'] ?></td>
			<td><?php echo $r['address'] ?></td>
			<td>Rp.<?php echo number_format($r['income']) ?>,-</td>
			<td><?php echo $r['created_at'] ?></td>
			<td>
				<a href="edit_person.php?id_person=<?php echo $r['id_person']; ?>" class="btn btn-warning">Edit</a>
				<a onclick="if(confirm('Apakah anda yakin ingin menghapus data person ini ??')){ location.href='hapus_person.php?id_person=<?php echo $r['id_person']; ?>' }" class="btn btn-danger">Hapus</a>
			</td>
		</tr>		
		<?php 
	}
	}
}else{
	include "../konfig.php";
	$sql4="SELECT  * from person,regions where person.region_id=regions.region_id LIKE '%$fil%' limit $start, $per_hal";
	$per2=mysqli_query($conn,$sql4);
	if(mysqli_num_rows($per2)>0){
		//output data setiap baris
		while($r=mysqli_fetch_array($per2)){
		?>
		<tr>
			<td><?php echo $r['id_person'] ?></td>
			<td><?php echo $r['name_person'] ?></td>
			<td><?php echo $r['name'] ?></td>
			<td><?php echo $r['address'] ?></td>
			<td>Rp.<?php echo number_format($r['income']) ?>,-</td>
			<td><?php echo $r['created_at'] ?></td>
			<td>
				<a href="edit_person.php?id_person=<?php echo $r['id_person']; ?>" class="btn btn-warning">Edit</a>
				<a onclick="if(confirm('Apakah anda yakin ingin menghapus data person ini ??')){ location.href='hapus_person.php?id_person=<?php echo $r['id_person']; ?>' }" class="btn btn-danger">Hapus</a>
			</td>
		</tr>		
		<?php 
	}
	}
}
}
?>
</table>
<ul class="pagination">			
			<?php 
			for($x=1;$x<=$halaman;$x++){
				?>
				<li><a href="?page=<?php echo $x ?>"><?php echo $x ?></a></li>
				<?php
			}
			?>						
		</ul>
<!-- modal input -->
<div id="myModal" class="modal fade">
	<div class="modal-dialog">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
				<h4 class="modal-title">Tambah Person Baru</h4>
			</div>
			<div class="modal-body">
				<form action="tambah_person.php" method="post">
					<div class="form-group">
						<label>Nama</label>
						<input name="name" type="text" class="form-control" placeholder="Nama ..">
					</div>
					<div class="form-group">
						<label>Region</label>
						 <select name="region">
						    <option value="" selected="selected">-</option>
							<?php
							include "../konfig.php";
							$query = "SELECT * FROM regions";
							$hasil = mysqli_query($conn,$query);
							while ($data = mysqli_fetch_array($hasil))
							{
							echo "<option value='".$data['region_id']."'>".$data['name']."</option>";
							}
							?>
					</div>
					<div class="form-group">
						<label>Alamat</label>
						<textarea name="alamat" class="form-control" placeholder="Alamat .."></textarea>
					</div>
					<div class="form-group">
						<label>Pemasukan</label>
						<input name="income" type="text" class="form-control" placeholder="Rp ..">
					</div>
				</div>
				<div class="modal-footer">
					<button type="button" class="btn btn-default" data-dismiss="modal">Batal</button>
					<input type="submit" class="btn btn-primary" value="Simpan">
				</div>
			</form>
		</div>
	</div>
</div>



<?php 
include 'footer.php';

?>