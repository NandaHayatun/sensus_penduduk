<?php 
include '../konfig.php';
$nama=$_POST['name'];
$date = date('Y-m-d H:i:s');
$sql="INSERT INTO regions (name,created_at) VALUES('$nama','$date')";
if(mysqli_query($conn,$sql)){
header("Location: region.php");
}
 ?>