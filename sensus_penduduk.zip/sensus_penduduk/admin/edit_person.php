<?php 
include 'header.php';
?>
<h3><span class="glyphicon glyphicon-briefcase"></span>  Edit Person</h3>
<a class="btn" href="person.php"><span class="glyphicon glyphicon-arrow-left"></span>  Kembali</a>
<?php
	$idedit=$_GET['id_person'];
	include "../konfig.php";
	$sql="SELECT * FROM person WHERE id_person='$idedit'";
	$result=mysqli_query($conn,$sql);
	while($data1 = mysqli_fetch_array($result)){
		$idambil=$data1['id_person'];
		$namanya=$data1['name_person'];
		$regionnya=$data1['region_id'];
		$alamatnya=$data1['address'];
		$gajinya=$data1['income'];
	}
	if($_SERVER["REQUEST_METHOD"]=="POST"){
		if(empty($_POST["nama"])){
      		$namaerr="Nama tidak boleh kosong!";
      	}if(empty($_POST["region"])){
      		$namaerr="Region tidak boleh kosong!";
      	}else{
      		$id=$_POST["id"];
      		$nama=test_input($_POST["nama"]);
      		$region=$_POST['region'];
			$alamat=$_POST['alamat'];
			$income=$_POST['income'];
      		if(!preg_match("/^[a-zA-Z]*$/",$nama)){
        		$namaerr="Only letters and white space allowed";
        	}else{
        		include "../konfig.php";
        		$date = date('Y-m-d H:i:s');
		        $sql2="UPDATE person set name_person='$nama',region_id='$region',address='$alamat',income='$income',created_at='$date' WHERE id_person='$id'"; 
		        /*$sql2="UPDATE `person` SET `region_id` = '$region', `address` = 'Jalan Adil', `income` = '1000000' WHERE `person`.`id_person` = $id"; */
		        if(mysqli_query($conn,$sql2)){
		        	header("Location: person.php");
		        }else{
		          echo "Error!";
		        }mysqli_close($conn);
        	}
      	}
      	
	}
	function test_input($data){
		$data = trim($data);
		$data = stripslashes($data);
		$data = htmlspecialchars($data);
		return $data;
	}
?>			
	<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post">
		<table class="table">
			<tr>
				<td>ID</td>
				<td><input type="text" name="id" value="<?php echo $idedit; ?>" readonly></td>
			</tr>
			<tr>
				<td>Nama</td>
				<td><input type="text" class="form-control" name="nama" value="<?php echo $namanya ?>"></td>
			</tr>
			<tr>
				<td>Region</td>
				<td>
				 <select name="region">
					 <option value="" selected="selected">-</option>
					<?php
					/*include "../konfig.php";
					$query = "SELECT * FROM regions,person where regions.region_id=person.region_id"; 
					
					$hasil = mysqli_query($conn,$query);
					
					while ($data = mysqli_fetch_array($hasil))
					{
						echo "<option value='".$regionnya."' selected='selected'>".$data['name']." </option>
						<option value='".$data['region_id']."'>".$data['name']."</option>";
					} */
					include "../konfig.php";
					$query = "SELECT * FROM regions";
					$hasil = mysqli_query($conn,$query);
					while ($data = mysqli_fetch_array($hasil))
					{
					echo "<option value='".$data['region_id']."'>".$data['name']."</option>";
					}
					?>
				</td>
			</tr>
			<tr>
				<td>Alamat</td>
				<td><textarea name="alamat" class="form-control" placeholder="Alamat .."><?php echo $alamatnya; ?></textarea></td>
			</tr>
			<tr>
				<td>Income</td>
				<td><input type="text" class="form-control" name="income" value="<?php echo $gajinya ?>"></td>
			</tr>

			<tr>
				<td></td>
				<td><input type="submit" class="btn btn-info" value="Ubah"></td>
			</tr>
		</table>
	</form>
<?php include 'footer.php'; ?>