<?php 
include 'header.php';
?>

<div class="col-md-10">
	<h3>Welcome</h3>	
    <h3>APLIKASI SENSUS PENDUDUK</h3>
    <h3>Created By : Nanda Hayatun Nufus</h3>
</div>
<br/>
	<table class="table table-hover">
	<tr>
		<th class="col-md-1">ID</th>
		<th class="col-md-3">Nama Region</th>
		<th class="col-md-1">Jumlah Penduduk</th>
		<th class="col-md-3">Total Pendapatan</th>
		<th class="col-md-3">Rata-rata Pendapatan</th>
		<th class="col-md-2">Status</th>
	</tr>

<?php 
include "../konfig.php";
/*$query=mysqli_query($conn, "SELECT region_id, name, COUNT(id_person) as jml_penduduk, sum(income) as total_pendapatan from person,regions group by region_id");
$jum=mysqli_fetch_array($query); */
$query= "SELECT region_id, name, COUNT(id_person) as jml_penduduk, sum(income) as total_pendapatan FROM person,regions GROUP BY region_id";
$per=mysqli_query($conn,$query);
if(mysqli_num_rows($per)>0){
while ($jum = mysqli_fetch_array($result1)) {        	
/*$jml_penduduk= ceil($jum['jml_penduduk']);
$tot_pendapatan = ceil($jum['total_pendapatan']);
$rata2pendapatan = ceil($jum['total_pendapatan']) / ceil($jum['jml_penduduk']);*/

	$jml_penduduk= ceil($jum['jml_penduduk']);
	$tot_pendapatan = ceil($jum['total_pendapatan']);
	$rata2pendapatan = ceil($jum['total_pendapatan']) / ceil($jum['jml_penduduk']);
	if((ceil($jum['total_pendapatan'])/ceil($jum['jml_penduduk']))< 1700000){
		$warna = "red";
	}else if(((ceil($jum['total_pendapatan'])/ceil($jum['jml_penduduk']))> 1700000) && ((ceil($jum['total_pendapatan'])/ceil($jum['jml_penduduk']))< 2200000)){
		$warna = "yellow";
	}else if((ceil($jum['total_pendapatan'])/ceil($jum['jml_penduduk']))> 2200000){
		$warna = "green";
	}

	echo"<tr>
			<td> $jum[region_id] </td>
			<td> $jum[name] </td>
			<td>$jml_penduduk </td>
			<td>number_format($tot_pendapatan)</td>
			<td>Rp. number_format($rata2pendapatan) -</td>
			<td><font color=$warna> Status</font></td>
		</tr>
	</table>";
}

}else{
	echo '<p></p><p>Tidak ada data</p>';
}mysqli_close($conn);
?>
<?php 
include 'footer.php';

?>