<?php
	$iddel=$_GET['id_person'];
	include "../konfig.php";
	$sql="DELETE FROM person WHERE id_person='$iddel'";
	if(mysqli_query($conn,$sql)){
		header("Location: person.php");
	}else{
		echo "Error!";
	}mysqli_close($conn);
	?>